**Foundry: [Sorkin Type Co](http://www.sorkintype.com)**

Poller is a high contrast semi-extended style Sans Serif. Poller is both readable and full of personality. Because of the higher contrast it is best used from medium sizes to larger display settings. Poller was inspired by hand lettering on early 20th century German posters.

Source files are available from [Google Code](http://code.google.com/p/googlefontdirectory/). To contribute to the project contact [Eben Sorkin](mailto:sorkineben@gmail.com).